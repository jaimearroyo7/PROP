package dominio;

import java.io.Serializable;

public class PalabraPeso implements Serializable{
    private String text;
    private double peso;

    public PalabraPeso(String text, double peso) {
        this.text = text;
        this.peso = peso;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
}

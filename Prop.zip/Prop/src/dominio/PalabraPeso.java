package dominio;

import java.io.Serializable;

public class PalabraPeso implements Serializable{
    private String text;
    private double peso;
    private static final long serialVersionUID = -7821004374586134671L;

    public PalabraPeso(String text, double peso) {
        this.text = text;
        this.peso = peso;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
}

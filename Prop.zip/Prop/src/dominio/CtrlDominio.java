package dominio;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;

import persistencia.CtrlPersistencia;

public class CtrlDominio implements Serializable{
	private CtrlPersistencia CP;
	private Documentos d;
	private static final long serialVersionUID = -7821004374586134671L;
	private ObjectInputStream ois;
	private BufferedReader b;
	public CtrlDominio() throws IOException, ParseException{
		CP = new CtrlPersistencia();
		d = new Documentos();
		
		File f = new File("src/persistencia/datos");
		File[] ficheros = f.listFiles();
		for (int i = 0; i < ficheros.length ; i++){
			if(ficheros[i].getName().equals("data.bin")){
				ois = new ObjectInputStream(new FileInputStream("src/persistencia/datos/data.bin"));
				try {
					d = (Documentos) ois.readObject();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		}
		
		/*
		ArrayList<String> docs = CP.datos("/home/jaime/workspace/PROP/src/persistencia/datos");
		for(int i = 0; i < docs.size(); ++i){
			String direccion = "/home/jaime/workspace/PROP/src/persistencia/datos/" + docs.get(i); 
			FileReader f = new FileReader(direccion);
	        BufferedReader b = new BufferedReader(f);
	        Documento d1 = new Documento();
	        d1.setTitulo(b.readLine());
	        d1.setAutor(b.readLine());
	        d1.setCategoria(b.readLine());
	        Texto t = new Texto(b.readLine());
	        d1.setTexto(t);
	        int k = d.addDoc(d1);
		}*/
	}
	public void addCarpeta(String direction) throws IOException, ParseException{
		ArrayList<String> docs = CP.datos(direction);
		for(int i = 0; i < docs.size(); ++i){
			String direccion = direction + "/" + docs.get(i); 
			FileReader f = new FileReader(direccion);
	        b = new BufferedReader(f);
	        Documento d1 = new Documento();
	        d1.setTitulo(b.readLine());
	        d1.setAutor(b.readLine());
	        d1.setCategoria(b.readLine());
	        StringBuilder txtb = new StringBuilder();
	        String linea = new String();
	        while((linea = b.readLine()) != null){
	        	txtb.append(linea);
	        	txtb.append(System.getProperty("line.separator"));
	        }
	        String txt = txtb.toString();
	        //System.out.println(txt);
	        Texto t = new Texto(txt);
	        
	        d1.setTexto(t);
	        @SuppressWarnings("unused")
			int k = d.addDoc(d1);
		}
	}
	
	public Documentos conjunto(){return d;}
	public CtrlPersistencia	control(){return CP;}
}

package interficie;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;

import dominio.ConsultaBooleana;
import dominio.ExpBool;
import dominio.Documento;

import java.awt.Font;

import javax.swing.JList;
import javax.swing.JScrollPane;

public class Ventana10 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private ArrayList<Documento> res;


	public Ventana10(final CtrlPresentacio c) {
		res = new ArrayList<Documento>();
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		this.setLocationRelativeTo(null);
		
		this.setVisible(true);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(12, 403, 117, 25);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed1(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnExit);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setBounds(402, 403, 117, 25);
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.volver(c.getVolver());
				dispose();
			}
		});
		contentPane.add(btnVolver);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(33, 120, 255, 254);
		contentPane.add(scrollPane);
		
		final JList list = new JList();
		list.setBounds(33, 120, 249, 99);
		scrollPane.setViewportView(list);
		
		JButton button = new JButton("<");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				c.llamarp1();
				dispose();
			}
		});
		button.setBounds(551, 403, 25, 25);
		contentPane.add(button);
		
		JLabel lblIntro = new JLabel("Expresión booleana");
		lblIntro.setFont(new Font("Dialog", Font.BOLD, 20));
		lblIntro.setBounds(170, 12, 256, 15);
		contentPane.add(lblIntro);
		
		JLabel lblExpresion = new JLabel("Expresion:");
		lblExpresion.setFont(new Font("Dialog", Font.BOLD, 14));
		lblExpresion.setBounds(33, 47, 117, 15);
		contentPane.add(lblExpresion);
		
		textField = new JTextField();
		textField.setBounds(119, 45, 307, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblEjemplo = new JLabel("Ejemplo de sintaxis y operadores:");
		lblEjemplo.setFont(new Font("Dialog", Font.ITALIC, 11));
		lblEjemplo.setBounds(33, 64, 255, 15);
		contentPane.add(lblEjemplo);
		
		JLabel lblelPerroAnd = new JLabel("\"el perro\" and (gato or animal) and not {casa mesa}");
		lblelPerroAnd.setFont(new Font("Dialog", Font.ITALIC, 10));
		lblelPerroAnd.setBounds(30, 76, 382, 15);
		contentPane.add(lblelPerroAnd);
		

		final JLabel selecciona = new JLabel("Selecciona!");
		selecciona.setBounds(321, 181, 105, 15);
		contentPane.add(selecciona);
		selecciona.setVisible(false);
		
		final JLabel error = new JLabel("Error de sintaxis!");
		error.setBounds(305, 103, 133, 15);
		contentPane.add(error);
		error.setVisible(false);
		
		final JLabel lblSinResultados = new JLabel("Sin resultados");
		lblSinResultados.setBounds(305, 103, 150, 15);
		contentPane.add(lblSinResultados);
		lblSinResultados.setVisible(false);
		
		JButton Buscar = new JButton("Buscar");
		Buscar.setFont(new Font("Dialog", Font.BOLD, 14));
		Buscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ExpBool exp = new ExpBool();
				int k = exp.setExpresio(textField.getText());
				if(k == -1){
					error.setVisible(true);
					lblSinResultados.setVisible(false);
				}
				else{
					error.setVisible(false);
					ConsultaBooleana cb = null;
					try {
						cb = new ConsultaBooleana(c.cd().conjunto(), textField.getText());
					} catch (ParseException | IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					res = cb.getResult();
					if(res.size() == 0){
						lblSinResultados.setVisible(true);
					}
					else lblSinResultados.setVisible(false);
					DefaultListModel dlm = new DefaultListModel();
					//errorSel.setVisible(false);
					for(int i = 0; i < res.size(); ++i){
						String s = res.get(i).getAutor() + ": " + res.get(i).getTitulo();
						dlm.addElement(s);
					}
					list.setModel(dlm);
				}
				
			}
		});
		Buscar.setBounds(309, 76, 117, 25);
		contentPane.add(Buscar);
		
		JButton btnVer = new JButton("Ver");
		btnVer.setFont(new Font("Dialog", Font.BOLD, 14));
		btnVer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(list.getSelectedIndex() == -1){
					selecciona.setVisible(true);
				}
				else{
					int i = list.getSelectedIndex();
					c.setAutor(res.get(i).getAutor());
					c.setTitulo(res.get(i).getTitulo());
					c.setVolver(10);
					c.llamarp3();
					dispose();
				}
			}
		});
		btnVer.setBounds(309, 144, 117, 25);
		contentPane.add(btnVer);
		
		
		
	}
}

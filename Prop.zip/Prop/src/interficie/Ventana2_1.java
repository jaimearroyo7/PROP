package interficie;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;

import javax.swing.JTextField;

import dominio.Documento;
import dominio.Texto;

import javax.swing.JLabel;
import javax.swing.JTextPane;

public class Ventana2_1 extends JFrame implements Serializable{

	private static final long serialVersionUID = -8716726458740190367L;
	private JPanel contentPane;
	private JTextField titulo;
	private JTextField autor;
	private JTextField Categoria;

	public Ventana2_1(final CtrlPresentacio c) {
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		this.setLocationRelativeTo(null);
		setUndecorated(true);
		this.setVisible(true);
		
		final Documento d = new Documento();
		
		final JLabel errortit = new JLabel("Introduce un título!");
		errortit.setVisible(false);
		errortit.setBounds(271, 14, 137, 15);
		contentPane.add(errortit);
		
		final JTextPane text = new JTextPane();
		text.setBounds(135, 106, 394, 203);
		contentPane.add(text);
		text.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		
		final JLabel erroraut = new JLabel("Introduce un autor!");
		erroraut.setVisible(false);
		erroraut.setBounds(271, 45, 152, 15);
		contentPane.add(erroraut);
		
		JButton button = new JButton("<");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				c.llamarp1();
				dispose();
			}
		});
		button.setBounds(551, 403, 25, 25);
		contentPane.add(button);
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean sigue = true;
				if(titulo.getText().isEmpty() || titulo.getText() == null){
					errortit.setVisible(true);
					sigue = false;
				}
				else errortit.setVisible(false);
				
				if(autor.getText().isEmpty() || autor.getText() == null){
					erroraut.setVisible(true);
					sigue = false;
				}
				else erroraut.setVisible(false);
				if(sigue){
				d.setTitulo(titulo.getText());
				d.setAutor(autor.getText());
				d.setCategoria(Categoria.getText());
				Texto t = new Texto(text.getText());
				try {
					d.setTexto(t);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					c.cd().conjunto().addDoc(d);
				} catch (ParseException | IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				c.llamarp2();
				dispose();
				}
			}
		});
		btnAceptar.setBounds(211, 333, 117, 25);
		contentPane.add(btnAceptar);
		
		titulo = new JTextField();
		titulo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		titulo.setBounds(139, 12, 114, 19);
		contentPane.add(titulo);
		titulo.setColumns(10);
		
		autor = new JTextField();
		autor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		autor.setBounds(139, 43, 114, 19);
		contentPane.add(autor);
		autor.setColumns(10);
		
		Categoria = new JTextField();
		Categoria.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		Categoria.setBounds(139, 73, 114, 19);
		contentPane.add(Categoria);
		Categoria.setColumns(10);
		
		JLabel lblTtulo = new JLabel("Título");
		lblTtulo.setBounds(61, 14, 70, 15);
		contentPane.add(lblTtulo);
		
		JLabel lblAutor = new JLabel("Autor");
		lblAutor.setBounds(61, 45, 70, 15);
		contentPane.add(lblAutor);
		
		JLabel lblCategoria = new JLabel("Categoria");
		lblCategoria.setBounds(51, 75, 70, 15);
		contentPane.add(lblCategoria);
		
		JLabel lblTexto = new JLabel("Texto");
		lblTexto.setBounds(61, 106, 70, 15);
		contentPane.add(lblTexto);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}
		});
		btnExit.setBounds(12, 403, 117, 25);
		contentPane.add(btnExit);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp2();
				dispose();
				}
		});
		btnVolver.setBounds(413, 403, 117, 25);
		contentPane.add(btnVolver);
		
		
	
	}
}
package interficie;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;
import java.awt.Component;

import javax.swing.Box;

import java.awt.Point;
import javax.swing.JLabel;
import java.awt.Font;

public class Principal extends JFrame implements Serializable{

	private JPanel contentPane;
	private boolean volver;
	
	
	public Principal(final CtrlPresentacio c) {
		setLocation(new Point(0, 0));
		volver = false;
		this.setVisible(true);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setLocationRelativeTo(null);
		
		JButton btnAadir = new JButton("Añadir");
		btnAadir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp2();
				dispose();
			}
		});
		btnAadir.setVisible(true);
		btnAadir.setBounds(44, 58, 369, 25);
		contentPane.add(btnAadir);
		
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp4();
				dispose();
			}
		});
		btnConsultar.setBounds(44, 95, 369, 25);
		btnConsultar.setVisible(true);
		contentPane.add(btnConsultar);
		
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}
		});
		btnExit.setBounds(56, 235, 117, 25);
		btnExit.setVisible(true);
		contentPane.add(btnExit);
		
		
		JButton btnBorrar = new JButton("Borrar o Modificar");
		btnBorrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				volver = true;
				c.setAutor(null);
				c.setTitulo(null);
				c.llamarp3();
				dispose();
			}
		});
		btnBorrar.setBounds(44, 132, 369, 25);
		btnBorrar.setVisible(true);
		contentPane.add(btnBorrar);
		
		
		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnGuardar.setBounds(308, 235, 117, 25);
		btnGuardar.setVisible(true);
		contentPane.add(btnGuardar);
		
		
		JButton btnNewButton = new JButton("Exportar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp17();
				dispose();
			}
		});
		btnNewButton.setBounds(44, 169, 369, 25);
		btnNewButton.setVisible(true);
		contentPane.add(btnNewButton);
		
		
		JLabel lblMenPrincipal = new JLabel("Menú Principal");
		lblMenPrincipal.setFont(new Font("Dialog", Font.BOLD, 17));
		lblMenPrincipal.setBounds(164, 12, 174, 32);
		lblMenPrincipal.setVisible(true);
		contentPane.add(lblMenPrincipal);
		
		
		
	}
	public boolean getVolver() {
		return volver;
	}
}
package interficie;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Ventana13 extends JFrame implements Serializable{

	private JPanel contentPane;
	private static final long serialVersionUID = -7821004374586134671L;

	public Ventana13(final CtrlPresentacio c) {
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		contentPane = new JPanel();
		contentPane.setFont(new Font("Dialog", Font.PLAIN, 14));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		this.setLocationRelativeTo(null);
		
		this.setVisible(true);
		
		JButton btnNewButton = new JButton("A partir de un documento");
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setVolver(13);
				c.llamarp14();
				dispose();
			}
		});
		btnNewButton.setBounds(132, 132, 330, 25);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("<");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				c.llamarp1();
				dispose();
			}
		});
		button.setBounds(551, 403, 25, 25);
		contentPane.add(button);
		
		JButton btnNewButton_1 = new JButton("A partir de una query");
		btnNewButton_1.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setVolver(13);
				c.llamarp15();
				dispose();
			}
		});
		btnNewButton_1.setBounds(132, 262, 330, 25);
		contentPane.add(btnNewButton_1);
		
		
		JLabel lblConsultas = new JLabel("Documentos parecidos");
		lblConsultas.setFont(new Font("Dialog", Font.BOLD, 20));
		lblConsultas.setBounds(159, 12, 330, 32);
		contentPane.add(lblConsultas);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Dialog", Font.BOLD, 14));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}
		});
		btnExit.setBounds(12, 403, 117, 25);
		contentPane.add(btnExit);
		
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Dialog", Font.BOLD, 14));
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(c.getVolver() != 13 && c.getVolver() != 14){
				c.volver(c.getVolver());
				dispose();
				}
				else{
					c.llamarp4();
					dispose();
				}
			}
		});
		btnVolver.setBounds(422, 403, 117, 25);
		contentPane.add(btnVolver);
	}
}

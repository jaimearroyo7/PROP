package interficie;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.ListSelectionModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.border.LineBorder;

import java.awt.Color;

import javax.swing.JTextArea;

import dominio.Texto;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;

import java.awt.Font;


public class Ventana7 extends JFrame implements Serializable{

	private JPanel contentPane;
	private JTextField campo;
	private JTextArea contenido;
    
	public Ventana7(final CtrlPresentacio c) {
			setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			WindowListener exitListener = new WindowAdapter() {

			    @Override
			    public void windowClosing(WindowEvent e) {
			        int confirm = JOptionPane.showOptionDialog(
			             null, "Desea cerrar la aplicacion?", 
			             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
			             JOptionPane.QUESTION_MESSAGE, null, null, null);
			        if (confirm == 0) {
			        	try {
							c.acabar();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.exit(1);
			        }
			    }
			};
			addWindowListener(exitListener);
			setBounds(100, 100, 588, 468);
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);

			this.setLocationRelativeTo(null);
			
			this.setVisible(true);
			JLabel lblCampoAModificar = new JLabel("Campo a modificar:");
			lblCampoAModificar.setFont(new Font("Dialog", Font.BOLD, 14));
			lblCampoAModificar.setBounds(37, 12, 204, 15);
			contentPane.add(lblCampoAModificar);
			
			JLabel label = new JLabel("");
			label.setBounds(37, 84, 70, 15);
			contentPane.add(label);
			
			JLabel lblEscribaAquiPor = new JLabel("Escriba aqui por lo que desee modificar:");
			lblEscribaAquiPor.setFont(new Font("Dialog", Font.BOLD, 14));
			lblEscribaAquiPor.setBounds(37, 66, 306, 15);
			contentPane.add(lblEscribaAquiPor);
			
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(37, 97, 352, 270);
			contentPane.add(scrollPane);
			
			contenido = new JTextArea();
			scrollPane.setViewportView(contenido);
			
			campo = new JTextField();
			campo.setBounds(275, 10, 114, 19);
			contentPane.add(campo);
			campo.setColumns(10);
			
			JLabel lblcamposDisponiblesTtuloautorcategoriatexto = new JLabel("(campos disponibles: titulo,autor,categoria,texto) ");
			lblcamposDisponiblesTtuloautorcategoriatexto.setFont(new Font("Dialog", Font.ITALIC, 12));
			lblcamposDisponiblesTtuloautorcategoriatexto.setBounds(37, 39, 391, 15);
			contentPane.add(lblcamposDisponiblesTtuloautorcategoriatexto);
			
			
			final JLabel ERR1 = new JLabel("ERROR!");
			ERR1.setFont(new Font("Dialog", Font.BOLD, 14));
			ERR1.setBounds(462, 204, 85, 14);
			contentPane.add(ERR1);
			ERR1.setVisible(false);

			final JLabel errcamp = new JLabel("Campo erroneo!");
			errcamp.setBounds(426, 12, 121, 15);
			contentPane.add(errcamp);
			errcamp.setVisible(false);
			
			
			JButton btnOk = new JButton("OK");
			btnOk.setFont(new Font("Dialog", Font.BOLD, 14));
			btnOk.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(campo.getText().equals("titulo") || campo.getText().equals("autor") || campo.getText().equals("categoria") ||campo.getText().equals("texto")){
					int f = 0;
					try {
						f = c.cd().conjunto().modificardoc(c.getTitulo(),c.getAutor(), campo.getText(), contenido.getText());
						
					} catch (IOException | ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					if(f != 1) {
						ERR1.setVisible(true);
					}
					else {
						c.setVolver(7);
						c.llamarp1();
						dispose();
					}
					}
					else{
						errcamp.setVisible(true);
					}
				}
			});
			btnOk.setBounds(271, 365, 117, 25);
			contentPane.add(btnOk);
			
			JButton btnVolver = new JButton("Volver");
			btnVolver.setFont(new Font("Dialog", Font.BOLD, 14));
			btnVolver.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					c.llamarp3();
					dispose();
					}
			});
			btnVolver.setBounds(430, 403, 117, 25);
			contentPane.add(btnVolver);
			
			JButton btnExit = new JButton("Exit");
			btnExit.setFont(new Font("Dialog", Font.BOLD, 14));
			btnExit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
				}
			});
			btnExit.setBounds(12, 403, 117, 25);
			contentPane.add(btnExit);
			
			JButton button = new JButton("<");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					c.llamarp1();
					dispose();
				}
			});
			button.setBounds(558, 403, 18, 25);
			contentPane.add(button);
			
			
	}
}

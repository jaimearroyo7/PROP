package interficie;

import java.io.IOException;
import java.io.Serializable;

public class Main implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7821004374586134671L;

	public static void main(String[] args) throws IOException {
		CtrlPresentacio c = new CtrlPresentacio();
		c.empezar();
	}
}

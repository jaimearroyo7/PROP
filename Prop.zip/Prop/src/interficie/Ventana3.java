package interficie;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;

import dominio.Texto;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import java.awt.Font;

public class Ventana3 extends JFrame implements Serializable{

	private JPanel buscar;
	private JTextField titulo;
	private JTextField autor;
	private JButton btnExit;
	private JTextArea resultado;
	
	public Ventana3(final CtrlPresentacio c) {
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		buscar = new JPanel();
		buscar.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(buscar);
		buscar.setLayout(null);

		this.setLocationRelativeTo(null);
		setUndecorated(true);
		this.setVisible(true);
		titulo = new JTextField();
		titulo.setBounds(104, 12, 311, 19);
		buscar.add(titulo);
		titulo.setColumns(10);
		titulo.setText(c.getTitulo());
		
		autor = new JTextField();
		autor.setBounds(104, 74, 311, 19);
		buscar.add(autor);
		autor.setColumns(10);
		autor.setText(c.getAutor());
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(108, 176, 281, 161);
		buscar.add(scrollPane);
		
		resultado = new JTextArea();
		scrollPane.setViewportView(resultado);
		
		final JLabel Vacos = new JLabel("CAMPOS VACIOS!");
		Vacos.setFont(new Font("Dialog", Font.BOLD, 14));
		Vacos.setBounds(22, 129, 148, 14);
		buscar.add(Vacos);
		Vacos.setVisible(false);
		
		final JLabel NEXI = new JLabel("NO EXISTE !");
		NEXI.setFont(new Font("Dialog", Font.BOLD, 14));
		NEXI.setBounds(10, 126, 139, 21);
		buscar.add(NEXI);
		NEXI.setVisible(false);
		
		JButton btnBuscar = new JButton("Ver");
		btnBuscar.setFont(new Font("Dialog", Font.BOLD, 14));
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean trobat = false;
				if(titulo.getText().isEmpty() || autor.getText().isEmpty() || titulo.getText() == null || autor.getText() == null) {
					Vacos.setVisible(true);
					NEXI.setVisible(false);
				}
				else{
					for(int i = 0; i < c.cd().conjunto().getDocs().size(); ++i){
						if(c.cd().conjunto().getDocs().get(i).getAutor().equals(autor.getText()) && c.cd().conjunto().getDocs().get(i).getTitulo().equals(titulo.getText())){
							i = c.cd().conjunto().getDocs().size(); 
							trobat = true;
						}
					}
					
					if(!trobat){
						Vacos.setVisible(false);
						NEXI.setVisible(true);
					}
					else {
						NEXI.setVisible(false);
						String tit = titulo.getText();
						String aut = autor.getText();
						Texto t = c.cd().conjunto().consultarTextoDadoTituloAutor(tit, aut);
						resultado.setText(t.getTexto());
					}
				}
			}
		});
		btnBuscar.setBounds(188, 124, 149, 25);
		buscar.add(btnBuscar);
		
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Dialog", Font.BOLD, 14));
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(c.getvolver()) c.llamarp1();				
				else c.llamarp4();
				dispose();
			}
		});
		btnVolver.setBounds(420, 403, 117, 25);
		buscar.add(btnVolver);
		
		btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Dialog", Font.BOLD, 14));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}
		});
		btnExit.setBounds(10, 403, 117, 25);
		buscar.add(btnExit);
		
		JLabel lblTtulo = new JLabel("Título");
		lblTtulo.setFont(new Font("Dialog", Font.BOLD, 14));
		lblTtulo.setBounds(16, 14, 70, 15);
		buscar.add(lblTtulo);
		
		JLabel label = new JLabel("Autor");
		label.setFont(new Font("Dialog", Font.BOLD, 14));
		label.setBounds(16, 76, 70, 15);
		buscar.add(label);
		
		final JLabel error = new JLabel("");
		error.setBounds(104, 208, 311, 15);
		buscar.add(error);
		
		
		JButton btnNewButton = new JButton("Modificar");
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean trobat = false;
				if(titulo.getText().isEmpty() || autor.getText().isEmpty() || titulo.getText() == null || autor.getText() == null) {
					Vacos.setVisible(true);
					NEXI.setVisible(false);
				}
				else{
					for(int i = 0; i < c.cd().conjunto().getDocs().size(); ++i){
						if(c.cd().conjunto().getDocs().get(i).getAutor().equals(autor.getText()) && c.cd().conjunto().getDocs().get(i).getTitulo().equals(titulo.getText())){
							i = c.cd().conjunto().getDocs().size(); 
							trobat = true;
						}
					}
					
					if(!trobat){
						Vacos.setVisible(false);
						NEXI.setVisible(true);
					}
					else {
						NEXI.setVisible(false);
						c.setTitulo(titulo.getText());
						c.setAutor(autor.getText());
						c.llamarp7();
						dispose();
					}
				}
			}
			
		});
		btnNewButton.setBounds(401, 198, 117, 25);
		buscar.add(btnNewButton);
		
		JButton btnBorrar = new JButton("Borrar");
		btnBorrar.setFont(new Font("Dialog", Font.BOLD, 14));
		btnBorrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				boolean trobat = false;
				if(titulo.getText().isEmpty() || autor.getText().isEmpty() || titulo.getText() == null || autor.getText() == null) {
					Vacos.setVisible(true);
					NEXI.setVisible(false);
				}
				else{
					for(int i = 0; i < c.cd().conjunto().getDocs().size(); ++i){
						if(c.cd().conjunto().getDocs().get(i).getAutor().equals(autor.getText()) && c.cd().conjunto().getDocs().get(i).getTitulo().equals(titulo.getText())){
							i = c.cd().conjunto().getDocs().size(); 
							trobat = true;
						}
					}
					
					if(!trobat){
						Vacos.setVisible(false);
						NEXI.setVisible(true);
					}
					else {
						NEXI.setVisible(false);
						
						String tit = titulo.getText();
						String aut = autor.getText();
						int b = c.cd().conjunto().borrardoc(tit, aut);
						if(b == 1){
							error.setText("Se ha borrado con éxito");
							titulo.setText(null);
							autor.setText(null);
							resultado.setText(null);
							
						}
						else error.setText("No existe documento");
					}
				}
			
			}
		});
		btnBorrar.setBounds(401, 294, 117, 25);
		buscar.add(btnBorrar);
		
		JButton button = new JButton("<");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				c.llamarp1();
				dispose();
			}
		});
		button.setBounds(549, 403, 25, 25);
		buscar.add(button);
		
		
		
	}
	
}

package interficie;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import dominio.Documento;

public class Ventana8 extends JFrame implements Serializable{
	
	private JPanel jpanel;
	private JTextField textField;
	private JList<String> list;
	private ArrayList<Documento> res;
	private static final long serialVersionUID = -7821004374586134671L;

	public Ventana8(final CtrlPresentacio c) {
		res = new ArrayList<Documento>();
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		jpanel = new JPanel();
		jpanel.setFont(new Font("Dialog", Font.PLAIN, 14));
		jpanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(jpanel);
		jpanel.setLayout(null);

		this.setLocationRelativeTo(null);
		
		this.setVisible(true);
		JLabel lblPrefijo = new JLabel("Categoria:");
		lblPrefijo.setFont(new Font("Dialog", Font.BOLD, 14));
		lblPrefijo.setBounds(48, 23, 106, 15);
		jpanel.add(lblPrefijo);
		
		final JLabel SinRes = new JLabel("Sin resultados");
		SinRes.setBounds(285, 40, 106, 15);
		jpanel.add(SinRes);
		SinRes.setVisible(false);
		
		textField = new JTextField();
		textField.setBounds(138, 21, 114, 19);
		jpanel.add(textField);
		textField.setColumns(10);
		
		final JLabel errorSel = new JLabel("Selecciona un doc. !");
		errorSel.setBounds(65, 351, 151, 19);
		jpanel.add(errorSel);
		errorSel.setVisible(false);
		

		final JLabel errornull = new JLabel("Campo vacío!");
		errornull.setBounds(148, 40, 104, 15);
		jpanel.add(errornull);
		errornull.setVisible(false);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setFont(new Font("Dialog", Font.BOLD, 14));
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				errorSel.setVisible(false);
				if(textField.getText().equals(null) || textField.getText().isEmpty()){
					errornull.setVisible(true);
					SinRes.setVisible(false);
				}
				else{ errornull.setVisible(false);
				res = c.cd().conjunto().consultarCategoria(textField.getText());
				if(res.size() == 0) SinRes.setVisible(true);
				else SinRes.setVisible(false);
				DefaultListModel<String> dlm = new DefaultListModel<String>();
				errorSel.setVisible(false);
				for(int i = 0; i < res.size(); ++i){
					String s = res.get(i).getAutor() + ": " + res.get(i).getTitulo();
					dlm.addElement(s);
				}
				list.setModel(dlm);}
			}
		});
		btnBuscar.setBounds(285, 21, 100, 19);
		jpanel.add(btnBuscar);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}
		});
		btnExit.setBounds(12, 403, 117, 25);
		jpanel.add(btnExit);
		
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Dialog", Font.BOLD, 14));
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp4();
				dispose();
				}
		});
		btnVolver.setBounds(423, 403, 117, 25);
		jpanel.add(btnVolver);
		
		JButton button = new JButton("<");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				c.llamarp1();
				dispose();
			}
		});
		button.setBounds(552, 403, 24, 25);
		jpanel.add(button);
		
		JButton titulos = new JButton("Ver");
		titulos.setFont(new Font("Dialog", Font.BOLD, 14));
		titulos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(list.getSelectedIndex() == -1){
					errorSel.setVisible(true);
				}
				else{
				int i = list.getSelectedIndex();
				c.setAutor(res.get(i).getAutor());
				c.setTitulo(res.get(i).getTitulo());
				c.llamarp3();
				dispose();}
			}
		});
		titulos.setBounds(276, 348, 151, 25);
		jpanel.add(titulos);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(65, 68, 362, 251);
		jpanel.add(scrollPane);
		
		list = new JList<String>();
		scrollPane.setViewportView(list);
		list.setBounds(65, 68, 350, 109);
		
		
		
		
		
	}
}

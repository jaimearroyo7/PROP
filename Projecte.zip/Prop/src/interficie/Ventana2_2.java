package interficie;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;

import javax.swing.JTextField;

import dominio.Documento;
import dominio.Texto;

import javax.swing.JLabel;

public class Ventana2_2 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public Ventana2_2(final CtrlPresentacio c) {
		this.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(68, 235, 117, 25);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed1(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnExit);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setBounds(321, 235, 117, 25);
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp2();
				dispose();
			}
		});
		contentPane.add(btnVolver);
		
		textField = new JTextField();
		textField.setBounds(68, 74, 235, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton Examinar = new JButton("Examinar");
		Examinar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int seleccion = fc.showOpenDialog(contentPane);
				
				if(seleccion == JFileChooser.APPROVE_OPTION){
					
					File fichero = fc.getSelectedFile();
					textField.setText(fichero.getAbsolutePath());
				}
			}
		});
		Examinar.setBounds(321, 71, 117, 25);
		contentPane.add(Examinar);
		
		JButton Importar = new JButton("Importar");
		Importar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String path = textField.getText();
				try {
					c.cd().addCarpeta(path);
				} catch (IOException | ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				c.llamarp2();
				dispose();
			}
		});
		Importar.setBounds(183, 118, 117, 25);
		contentPane.add(Importar);
	}
}
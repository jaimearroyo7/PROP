/**
 * @mainpage Practica PRO2: Gestor de Tasques / Agenda
 
Esta práctica consiste en crear un gestor de tareas o agenda,con un reloj interno concreto y que podenmos modificar, la cual
Se le intoducen comandas y se pueden consultar, insertar de nuevas, modifcar
algunas que ya esten, comprovar que cumplen ciertas expresiones o contiene
ciertas etiquetas... Esta constituido por las clases
<em> Agenda</em>, <em> Rellotge</em> y <em> Tasca</em>.
*/

/** @file program.cc
    @brief Programa principal para la práctica <em>Gestor de Tasques / Agenda</em>.
*/


#include "rellotge.hh"
#include "agenda.hh"
#include "comanda.hh"


/**   @brief Programa principal para la práctica <em>Gestor de Tasques / Agenda</em>.
*/



int main(){
    Agenda a;
    Rellotge r;
    Comanda c;
    bool b;
    while (c.llegir(b)){
        if (b){
            if(c.es_rellotge()){
                if (c.es_consulta()) {
					r.escriure();
					cout << endl;
				}
	            else {
					Rellotge aux(r);
	                aux.modificar_rellotge(c);
	                if (aux < r) cout << "No s'ha realitzat" << endl;
					else r = aux;
	            }
	        }
            else if (c.es_insercio()) a.inserir(c,r);
            else if (c.es_consulta()){
                if (c.es_passat()) a.consultar_passat(r);
                else a.consultar_futur(c,r);
            }
            else if( c.es_modificacio()){
	                 a.modificar(c, r); 
            }
            else if (c.es_esborrat()){
                a.esborrar(c,r);//mirarem etiquetes i depenent del nombre qe retorni la funcio int nombre_etiquetes sabrem qe hem borrar
	        }
        }
    }
} 

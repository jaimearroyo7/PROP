/** @file agenda.hh
@brief Especificacion de la clase Agenda
*/

#ifndef AGENDA_HH
#define AGENDA_HH

#include "comanda.hh"
#include "rellotge.hh"
#include "tasca.hh"
#include <map>


/** @class Agenda
@brief Representa la Agenda donde estan referenciadas todas las tareas y a su vez contiene el Menu. Puede usarse para consultar tareas futuras o pasadas al Relotge del programa o bien insertar, modificar o borrar alguna tarea del Menu  */
class Agenda{
private:
    typedef map<Rellotge,Tasca>::iterator itMap;
	map<Rellotge,Tasca> A; 
	vector< itMap > M;

	
	/**@brief Borra toda una Tasca del Menu
 
	*\PRE Cierto
	*\POST El resultado es el parametro implicito con el Menu sin tener referenciada la Tasca numero k */  
	void esborra_tasca(int&k);
	
	
	/**@brief Borra una etiqueta de una Tasca del Menu
 
	*\PRE Cierto
	*\POST El resultado es el parametro implicito con una Tasca referenciada en el Menu sin la etiqueta dada por la comanda c  */  
	void esborra_etiqueta(int&k,Comanda&c );
	
	/**@brief Borra totes les etiquetes de una Tasca del Menu
 
	*\PRE Cierto
	*\POST El resultado es el parametro implicito con una Tasca referenciada en el Menu sin todas sus etiquetas */  
	void esborra_totes_etiquetes(int&k);
	
	/**@brief Escribe todas las Tareas del Menu que cumplen la expresion
 
	*\PRE Cierto
	*\POST Saca por el canal estandard las Tascas referenciadas en el Menu que estan en el intervalo marcado por ini i fi, y que cumplen la expresion dada por expressio */  
	void escriure_tasques_expressio_interval(itMap ini,itMap fi,string&expressio);
	
	/**@brief sacamos por pantalla todas las tareas a partir del reloj interno
	
	*\PRE: 
	*\POST: */
	void consultar_totes_futures(Rellotge& r);

	/**@brief Escribe todas las Tareas del Menu que tengan la etiqueta dada
 
	*\PRE Cierto
	*\POST Saca por el canal estandard las Tascas referenciadas en el Menu que estan en el intervalo marcado por ini i fi, y que tienen referenciada la etiqueta del parametro de entrada */  
	void escriure_tasques_etiqueta_interval(itMap ini,itMap fi,string&etiqueta);
	
	
	/**@brief Escribe todas las Tareas del Menu que estan en el intervalo de tiempo determinado
 
	*\PRE Cierto
	*\POST Saca por el canal estandard las Tascas referenciadas en el Menu que estan en el intervalo marcado por ini i fi */  
	void escriure_tasques_interval(itMap ini,itMap fi);
    

	
	
public:
	/*Constructoras*/
	
	/**@brief Creadora por defecto. Se ejecuta automaticamente al crear la Agenda. Solo hay 1 en el programa;
 
	*\PRE Cierto
	*\POST El resultado es una Agenda (un map con llave Relotge i Tasca) con un Menu vacio y ninguna tasca referenciada a ningun Rellotge */  
	Agenda();
	
	/*Destructoras*/
	
	/**@brief Destructora por defecto
	*\PRE Cierto
	*\POST Destructora por defecto*/
	~Agenda();
	
	
	/*Modificadoras*/
	
	/**@brief Insertar una Tasca 
	Dada una Comanda de entrada, inserta una Tasca referenciada a un Rellotge en la Agenda
	
	*\PRE Agenda inicializada
	*\POST El resultado es la Agenda con la nueva Tasca anadida*/ 
	void inserir(Comanda&c,const Rellotge&act);	
	
	/**@brief Borrar una Tasca de la Agenda
	Dada una comanda de esborrar referente a una tasca concreta, la borrara toda, todas sus etiquetas o una concreta.
	
	*\PRE Agenda inicializada y comanda C correcta
	*\POST Dada una comanda del tipo esborrar, borrara de la Agenda una Tasca concreta (el iterador correspondiente en el Menu) o bien de esa Tasca concreta borrar una etiqueta concreta, o bien todas las etiquetas de dicha Tasca  */
	void esborrar(Comanda& c, const Rellotge& r);
	
	/**@brief Modificar una Tasca de la Agenda 
	
	*\PRE La comanda c tiene que ser correcta
	*\POST La Tasca ha sido modificada segun los criterios de la comanda c*/
	void modificar(Comanda&c,const Rellotge&act);	
	/*Consultora*/
	
	/**@brief Consultar las Tascas con un Rellotge previo al que marca el Rellotge del programa.
	
	*\PRE Una agenda inicializada 
	*\POST Saca por el canal de salida todas las Tascas que tiene un Rellotge mas pequeno que el Rellotge del programa*/
	void consultar_passat(Rellotge&r) ;
	
	
	/**@brief Consultar las Comandas con un Rellotge posterior al que marca el Rellotge del programa.
	
	*\PRE Una agenda inicializada 
	*\POST Saca por el canal de salida, dependiendo de la comanda c, o bien todas las Tascas futuras al Rellotge del programa, o bien a un intervalo futuro de Rellotge concreto, ademas de poder tener que cumplir algun expresion boleana o tener alguna etiqueta determinada*/
	void consultar_futur(Comanda&c,const Rellotge&r);
	

};
#endif
	
	
	
	

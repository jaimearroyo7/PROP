/** @file rellotge.hh
@brief Classe Rellotge
*/

#ifndef RELLOTGE_HH
#define RELLOTGE_HH

#include "comanda.hh"

/** @class Rellotge
@brief Clase con la qual marcaremos un tiempo concreto, dando una data y una hora */

class Rellotge{

private:
    string hora;
    string data;
    
public:
	/*Constructoras*/
	
	/**@brief Creadora por defecto. 
	Se ejecuta automaticamente al declarar el Rellotge inicial, solo hay 1 Reloj para referenciar el tiempo en el programa principal.
	
	\PRE Cierto
	\POST El resultado es el Rellotge con la hora inicializada en 00:00 y la data en 20.04.15 */
	Rellotge();
	
	/**@brief Creadora por copia.
	Crea una copia de un Rellotge
	
	\PRE Cierto
	\POST El resultado es un Rellotge con los mismos parámetros que el Rellotge que damos como parámetro.*/
	
	Rellotge(const Rellotge&r);
	
	/**@brief Creadora por parámetros.
	 * Crea un Rellotge dados unos parámetros.
	
	\PRE Cierto
	\POST El resultado es un Rellotge inicializado segun los parámetros de entrada */
	Rellotge(string d,string h);
	
	/*Destructoras*/
	
	/**@brief Destructora por defecto
	
	\PRE Cierto
	\POST Destructora por defecto*/
	~Rellotge();
	
	
	/*Modificadoras*/
	
	/**@brief Modifica el Rellotge
	Dados una data y hora distintos, actualitza el Rellotge implícito
	
	\PRE Rellotge ya esta inicializado
	\POST El resultado es el Rellotge implícito con los parametros modificados según la hora y data que marque la comanda */ 
	
	bool modificar_rellotge(Comanda&c);
	
	    
	/*Consultoras*/
    
	/**@brief Consultar la hora del Rellotge
    
	\PRE Cierto
	\POST Saca por el canal estándard la hora del Rellotge implícito*/
	string consultar_hora() const;
    
    
	/**@brief Consultar la data del Rellotge
     
	\PRE Cierto
	\POST Saca por el canal estándard la data del Rellotge implícito*/
	string consultar_data() const;
      
	
	
	/**@brief Operador "<" para Rellotge
	 * Indicara si el tiempo que marca el Rellotge implicito es previo al del Rellotge pasado como parámetro
	
	\PRE Cierto
	\POST El resultado es un valor boleano donde será cierto si el tiempo cronológico que marca el Rellotge implicito es previo al del Rellotge pasado como parámetro*/
	bool operator < (const Rellotge&b) const;
      
    
	/**@brief Indica si el tiempo que marca Rellotge implicito es igual al del Rellotge pasado como parámetro
	

	\PRE Cierto
	\POST El resultado es un valor boleano donde será cierto si el tiempo cronológico que marca el Rellotge implicito es igual al del Rellotge pasado como parámetro*/
	bool operator == (const Rellotge&b) const;
    
	/**@brief Indica si el tiempo que marca Rellotge implicito es diferente al del Rellotge pasado como parámetro


	\PRE:Cierto
	\POST: El resultado es un valor boleano donde será cierto si el tiempo cronológico que marca el Rellotge implicito es diferente al del Rellotge pasado como parámetro*/
	bool operator != (const Rellotge&b) const;
	
	/*Entrada y salida*/
	
	/**@brief Escribe el Rellotge implícito
	
	\PRE: Cierto
	\POST: Saca por el canal de salida estándard la hora i data del Rellotge implícito */
	void escriure() const;
	
	
};
#endif

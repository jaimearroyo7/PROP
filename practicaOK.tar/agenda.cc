#include "agenda.hh"

//PRE: cierto
//POST: El resultado es una agenda, con el reloj interno a la hora en 00:00 20.04.15, un  vacio y la agenda vacia */  
Agenda::Agenda(){}
	
//PRE: Cierto
//POST: Destructora por defecto*/
Agenda::~Agenda(){}
	
//PRE: Agenda inicializada y comanda C correcta
//POST: Se ha modificado la tarea indicada por la comanda c segun sus criterios */ 
void Agenda::esborrar(Comanda& c, const Rellotge& r){
	Rellotge r1;
	//FALTA COMRPOVAR QE EL RELLOTGE NO ES PASSAT
	//if (r > r1){
		string s = c.tipus_esborrat();
		int k = c.tasca();
		if (k >= 0 and k <= M.size()) {
			itMap it = M[k-1]; //-1 es per la tasca
			if (it != A.end()) {
				if (r < it->first or r == it->first) {
					if (s == "tasca") esborra_tasca(k);
					else if (s == "etiqueta") esborra_etiqueta(k, c);
					else esborra_totes_etiquetes(k);
				}
				else cout << "No s'ha realitzat" << endl;
			}
			else cout << "No s'ha realitzat" << endl;
		}
		else cout << "No s'ha realitzat" << endl;
	//}
	//else cout << "No s'ha realitzat" << endl;
}

//PRE:  previamente creado 
//POST: Borra la tasca de la k-essima posicion del . Si no hubiere nada o no existe tal posicio sacar un mensaje de error*/     
void Agenda::esborra_tasca(int& k){
    if (k <= M.size()) {
        itMap it = M[k-1]; //M vector de iteradores 
        if (it != A.end()) {
            A.erase(it);
            M[k-1] = A.end();
        }
        else cout << "No s'ha realitzat" << endl;
    }
    else cout << "No s'ha realitzat" << endl;
}
	
//PRE:  previamente creado
//POST: Borra les etiquetes de la tasca de la k-essima posicion del . Si no hubiere nada o no existe tal posicion sacar un mensaje de error*/
void Agenda::esborra_etiqueta(int& k, Comanda& c){
    if (k <= M.size()) {
        itMap it = M[k-1]; //M vector de iteradores 
        if (it != A.end() and c.nombre_etiquetes() == 1)
            (*it).second.esborrar_etiqueta(c.etiqueta(1));
        else cout << "No s'ha realitzat" << endl;
    }
    else cout << "No s'ha realitzat" << endl;
}

//PRE: Cierto
//POST: Borra todas las etiquetas de la tasca k-esima */
void Agenda::esborra_totes_etiquetes(int &k){
    if (k <= M.size()) {
        itMap it = M[k-1]; //M vector de iteradores 
        if (it != A.end())
            (*it).second.esborrar_totes_etiquetes();
        else cout << "No s'ha realitzat" << endl;
    }
    else cout << "No s'ha realitzat" << endl;
}
	
//PRE: Agenda inicializada
//POST: El resultado es la agenda con la nueva comanda añadida*/ 
void Agenda::inserir(Comanda& c,const Rellotge&act){
    Rellotge r(act);
    r.modificar_rellotge(c);
    itMap it = A.find(r);
    if (it == A.end() and (act < r or act == r)) {
        Tasca t;
        t.afegir_titol(c);
        t.afegir_etiquetes(c);
        A[r] = t;   //El map crea la posicion 'r'(reloj con el valor de r) y le insertamos la tasca 't'
    }
    else cout << "No s'ha realitzat" << endl;
}

void Agenda::modificar(Comanda& c, const Rellotge& act){
    int k = c.tasca();
    if (k >= 0 and k <= M.size()) {
        itMap it = M[k-1];
        if (it != A.end()) {
			if(act < it->first or act == it->first) {
				Tasca t = (*it).second;
				Rellotge r = (*it).first;
				r.modificar_rellotge(c);
				if (r < act) cout << "No s'ha realitzat" << endl; 
				else {
					t.afegir_titol(c);
					t.afegir_etiquetes(c);
					if (r == (*it).first) (*it).second = t;
					else {
						bool b = (A.find(r) == A.end());
						if (b) {
							A.erase((*it).first);
							A[r] = t;
							M[k-1] = A.find(r);
						}
						else cout << "No s'ha realitzat" << endl;
					}
				}
			}
			else cout << "No s'ha realitzat" << endl;
        }
        else cout << "No s'ha realitzat" << endl;
    }
    else cout << "No s'ha realitzat" << endl;
}
	
//PRE: Una agenda inicializada 
//POST: Guarda en  con todas las comandas de la agenda previas al tiempo que marca el reloj interno */
void Agenda::consultar_passat(Rellotge& r)  {
    itMap fi = A.lower_bound(r);//si el troba el retorna i sino retorna el que esta mes aprop cap a dalt
    itMap it = A.begin();
    escriure_tasques_interval(it, fi);
}
	
//PRE: Una agenda inicializada 
//POST: */

void Agenda::consultar_futur(Comanda& c, const Rellotge& r){
    string d1, d2, etiqueta, expressio;
    d1 = d2 = expressio = etiqueta = "";
    if (c.te_expressio()) expressio = c.expressio();
    if (c.nombre_etiquetes() == 1) etiqueta = c.etiqueta(1);
    
	itMap ini, fi;
	int nd = c.nombre_dates();
	if (nd == 0) {
		ini = A.lower_bound(r);
		fi = A.end();
	}
	else if (nd == 1) {
		Rellotge r1(c.data(1), "00:00");
		Rellotge r2(c.data(1), "23:59");
		ini = A.lower_bound(r1);
		fi = A.upper_bound(r2);
	}
	else {
		if (c.data(1) <= c.data(2)) {
			Rellotge r1(c.data(1), "00:00");
			Rellotge r2(c.data(2), "23:59");
			ini = A.lower_bound(r1);
			fi = A.upper_bound(r2);
		}
		else ini = fi = A.end();
	}
	if (etiqueta != "") escriure_tasques_etiqueta_interval(ini, fi, etiqueta);
	else if(expressio != "") escriure_tasques_expressio_interval(ini, fi, expressio);
	else escriure_tasques_interval(ini, fi);
}

void Agenda::escriure_tasques_interval(itMap ini, itMap fi){
  
    M= vector< itMap >(0);
    int cont = 1;
    
    itMap it = ini;
    while(it != fi){
		M.push_back(it);  
		cout << cont << " ";
		(*it).second.escriure_titol();
		cout << " ";
		(*it).first.escriure();
		(*it).second.escriure_etiquetes();
		cout << endl; 
        ++it;
        ++cont;
    }

}

void Agenda::escriure_tasques_expressio_interval(itMap ini,itMap fi, string& expressio){
    M= vector< itMap >(0);
    int cont = 1;
    itMap it = ini;
    while(it != fi){
		//cout << "tasca ";
		//(*it).second.escriure_titol();
		//cout << endl;
        if((*it).second.cumpleix_expressio(expressio)){
            M.push_back(it);  
            cout << cont << " ";
			(*it).second.escriure_titol();
			cout << " ";
			(*it).first.escriure();
			(*it).second.escriure_etiquetes();
			cout << endl;
			++cont;
        }
        ++it;

    }

}

//PRE: 
//POST: */
void Agenda::escriure_tasques_etiqueta_interval(itMap ini,itMap fi, string& etiqueta){
    M= vector< itMap >(0);
    int cont = 1;
    
    itMap it = ini;
    while(it != fi){
        if((*it).second.te_etiqueta(etiqueta)){
            M.push_back(it);  
            cout << cont << " ";
			(*it).second.escriure_titol();
			cout << " ";
			(*it).first.escriure();
			(*it).second.escriure_etiquetes();
			cout << endl;
			++cont;
        }
        ++it;

    }

}
#include "tasca.hh"

//PRE: Cierto
//POST: El resultdo es una tarea vacia
Tasca::Tasca(){ }

//PRE: Cierto
//POST: Destructora por defecto
Tasca::~Tasca(){ }
 
//PRE: Cierto
//POST:Se han borrado una o todas las etiquetas segun los criterios del string s*/    
void Tasca::esborrar_etiqueta(const string& s){
    map<string,int>::iterator it = etiquetes.find(s);
    if (it != etiquetes.end())
        etiquetes.erase(it);
    else cout << "No s'ha realitzat" << endl;
}
    
  /**@brief Borra todas las etiquetas de la tarea indicada
\PRE: Cierto
\POST:Se han borrado toda la tarea*/
void Tasca::esborrar_totes_etiquetes() {
    etiquetes.clear();
}

//PRE: la comanda c tiene que ser correcta
//POST:la tarea contendra el titulo segun los criterios de la comanda c */
void Tasca::afegir_titol(Comanda& c){
    if (c.te_titol()) titol = c.titol(); 
}

bool Tasca::cumpleix_expressio(string expressio) {
	int i = 0;
	return i_cumpleix(expressio, i);
}

bool Tasca::i_cumpleix(string expressio, int& i){
	bool b;
	//cout << "char " << i << ", " << expressio[i] << endl;
	if (expressio[i] == '#') {
		string eti = treure_eti_exp(expressio, i);
		//cout << "eti " << eti << endl;
		 map<string,int>::iterator it = etiquetes.find(eti);
		b = (it != etiquetes.end());
	}
	else {
		++i;
		b = i_cumpleix(expressio, i);
		char op = expressio[i];
		++i;
		bool b1 = i_cumpleix(expressio,i);
		++i;
		if (op == '.') b = b and b1;
		else b = b or b1;
	}
	return b;
}

string Tasca::treure_eti_exp(string expressio, int& i){
	char c = expressio[i];
	int j = i;
	while ( c != '.' and c!= ',' and  c != ')') {
		++i;
		c = expressio[i];
	}
	//cout << endl;
	return expressio.substr(j, i-j);
}

/**@brief se añade una etiqueta con el string s en la tarea indicada

\PRE: Cierto
\POST:Se ha añadido una etiqueta segun los criterios del string s*/
void Tasca::afegir_etiquetes(Comanda& c){
    int cont = c.nombre_etiquetes();
    while(cont > 0){
        string s = c.etiqueta(cont);
        etiquetes[s]; //afegim l'string
        --cont;
    }
}
    

//PRE:Cierto
//POST:Escribe la tarea por el canal estandard de salida
void Tasca::escriure_titol()const{
    cout << titol;
}

//PRE:
//POST: */
void Tasca::escriure_etiquetes()const{
    map<string,int>::const_iterator it = etiquetes.begin();
    while (it != etiquetes.end()) {
        cout << " " << (*it).first;
        ++it;
    }
}

bool Tasca::te_etiqueta(string& etiq){
    return etiquetes.find(etiq) != etiquetes.end();
}

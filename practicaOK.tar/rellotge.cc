#include "rellotge.hh"

//PRE: cierto
//POST: El resultado es el reloj de la agenda inicializad en 00:00 20.04.15
Rellotge::Rellotge(){
    hora = "00:00";
    data = "20.04.15";
}

Rellotge::Rellotge(const Rellotge& r){
    hora = r.hora;
    data = r.data;
}


Rellotge::Rellotge(string d, string h){
    hora = h;
    data = d;
}

//PRE:Cierto
//POST: Destructora por defecto
Rellotge::~Rellotge(){}


//PRE: cierto
//POST: el resultado es la hora del parametro implicito
string Rellotge::consultar_hora() const{
    return hora;
}

//PRE: cierto
//POST: el resultado es data del parametro implicito
string Rellotge::consultar_data() const{
    return data;
}

//PRE: Reloj ya esta inicializado
//POST: El resultado es el reloj de la agenda actualitzado
bool Rellotge::modificar_rellotge(Comanda &c){
    bool modificat = false;
    if(c.nombre_dates() != 0){
        data = c.data(1);
		modificat = true;
	}
	//sino te data, li posem la data del r.i.
    if(c.te_hora()){
        hora = c.hora();
		modificat = true;
	}
	return modificat;
}


//PRE:cert
//POST: el resultat indica si el parametre implicit es mes petit que el rellotge b
bool Rellotge::operator < (const Rellotge &b) const{
    string any1 = data.substr(6,2); //data[6] + data[7];
    string any2 = b.data.substr(6,2);//b.data[6] + b.data[7];
    bool b1 = false;
    if (any1 == any2) {
        string mes1 = data.substr(3,2);//data[3] + data[4];
        string mes2 = b.data.substr(3,2);//b.data[3] + b.data[4];
        if (mes1 == mes2) {
            string dia1 = data.substr(0,2);//data[0] + data[1];
            string dia2 = b.data.substr(0,2);//b.data[0] + b.data[1];
            if (dia1 == dia2) b1 = (hora < b.hora);
            else b1 =(dia1 < dia2);
        }
        else b1 =(mes1 < mes2);
    }
    else b1= (any1 < any2);  
    return b1;
}

//PRE:cert
//POST: el resultat indica si el parametre implicit es igual que el rellotge b
bool Rellotge::operator == (const Rellotge &b) const{
    return (hora == b.hora) and (data == b.data);
}
bool Rellotge::operator != (const Rellotge &b) const{
    return (hora != b.hora) or (data != b.data);
}
//PRE: cierto
//POST: muestra la fecha que tiene el Reloj actual de la Agenda por el canal estandard de salida
void Rellotge::escriure() const{
    cout << data << " " << hora; 
}

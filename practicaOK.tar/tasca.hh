/** @file tasca.hh
@brief Classe Tasca
*/

#ifndef TASCA_HH
#define TASCA_HH

#include <map>
#include "comanda.hh"

/** @class Tasca
@brief Representa los elementos que contiene la Agenda i serán referenciados en el Menu, estructurados por un títol i referencias a una serie de etiquetas, que son las etiquetas que tiene la Tasca
*/

class Tasca {

private:
    string titol;
    map<string,int> etiquetes;
    
   
    
    /*Consultoras*/
	
	/**@brief Indica si cumple la expresion boleana, aprovechando la inmersión con una variable int auxiliar.
	
	*\PRE:Cierto
	*\POST:El resultado es un valor boleano donde sera cierto si las etiquetas referenciadas en la Tasca cumplen la expresión boleana entrada por el parámetro implícito en la posición i*/
	
	bool i_cumpleix(string expressio, int& i);
	
	

    
    /**@brief Saca de la expresion boleana las etiquetas que la forman
    
    *\PRE:Cierto
    *\POST:El resultado es un substring,etiqueta, del string,expresio, que entra como parámetro implicito des de la posicion i*/
    string treure_eti_exp(string expressio, int& i);
    
public:
    
    /*Constructoras*/
    
    /**@brief Creadora por defecto, crea una tarea vacia
    
    \PRE: Cierto
   \POST: El resultdo es una Tasca vacia: sin títol i sin ninguna etiqueta referenciada */ 
    Tasca();
    
    /*Destructora*/
    
    /**@brief Destructora por defecto*/
    
    //PRE:Cierto
    //POST: Destructora por defecto
    ~Tasca();
    
    
    /*Modificadoras*/
    
    /**@brief Borra la etiqueta expresada por el string s de la Tasca indicada
    
    \PRE Cierto
    \POST El resultado es la Tasca implicita sin referenciar ya a la etiqueta(string) marcada por el parámetro de entrada*/
    void esborrar_etiqueta(const string& s);
    
    /**@brief Borra todas las etiquetas de la Tasca indicada
    \PRE Cierto
    \POST El resultado es el parámetro implicito sin referenciar a ninguna etiqueta*/    
    void esborrar_totes_etiquetes();
    
    /**@brief Añade el titulo a la Tasca según los criterios de la comanda c
    
    *\PRE La comanda c tiene que ser correcta
    *\POST El resultado es la Tasca implícita con el titol que indica la comanda c */
    void afegir_titol(Comanda& c);
    
    /**@brief Añade una etiqueta con el string s en la Tasca indicada
    
    *\PRE Cierto
    *\POST El resultado es la Tasca implícita con referencia a las etiquetas marcadas por la comanda c */
    void afegir_etiquetes(Comanda& c);
    
        
    
    /*Entrada y Sortida*/
    
    /**@brief Escribe la Tasca 
    
    *\PRE Cierto
    *\POST Saca por el canal estándard de salida el títol y las etiquetas referenciadas en la Tasca implicita*/
    void escriure_titol()const;
    
    /**@brief Escribe las etiquetas
    
    *\PRE Cierto
    *\POST Saca por el canal estándard de salida las etiquetas referenciadas en la Tasca implícita*/
    void escriure_etiquetes()const;
	/**@brief Indica si tiene uan etiqueta concreta
	
	*\PRE:Cierto
	*\POST:El resultado es un valor boleano donde será cierto si la Tasca referencia a la etiqueta etiqueta entrada por el parámetro implícito*/
	bool te_etiqueta(string& etiq);
	
	
	/**@brief Indica si cumple la expresion boleana
	
	*\PRE:Cierto
	*\POST:El resultado es un valor boleano donde sera cierto si las etiquetas referenciadas en la Tasca cumplen la expresión boleana entrada por el parámetro implícito*/
	
	bool cumpleix_expressio(string expressio);
	
	

};
#endif

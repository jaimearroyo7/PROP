package interficie;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;

import dominio.ConsultaBooleana;
import dominio.ExpBool;
import dominio.Documento;

import java.awt.Font;

import javax.swing.JList;

public class prueba extends JFrame {

	private JPanel contentPane;
	private JTextField textField;


	/**
	 * Create the frame.
	 */
	public prueba(final CtrlPresentacio c) {
		this.setVisible(true);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(68, 235, 117, 25);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed1(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnExit);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setBounds(321, 235, 117, 25);
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp2();
				dispose();
			}
		});
		contentPane.add(btnVolver);
		
		
		final JList list = new JList();
		list.setBounds(33, 120, 249, 99);
		contentPane.add(list);
		
		JLabel lblIntro = new JLabel("Expresión booleana");
		lblIntro.setBounds(170, 12, 140, 15);
		contentPane.add(lblIntro);
		
		JLabel lblExpresion = new JLabel("Expresion:");
		lblExpresion.setBounds(33, 47, 117, 15);
		contentPane.add(lblExpresion);
		
		textField = new JTextField();
		textField.setBounds(119, 45, 307, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblEjemplo = new JLabel("Ejemplo de sintaxis y operadores:");
		lblEjemplo.setFont(new Font("Dialog", Font.ITALIC, 11));
		lblEjemplo.setBounds(33, 74, 255, 15);
		contentPane.add(lblEjemplo);
		
		JLabel lblelPerroAnd = new JLabel("\"el perro\" and (gato or animal) and not {casa mesa}");
		lblelPerroAnd.setFont(new Font("Dialog", Font.ITALIC, 10));
		lblelPerroAnd.setBounds(33, 93, 382, 15);
		contentPane.add(lblelPerroAnd);
		
		JButton Buscar = new JButton("Buscar");
		Buscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ExpBool exp = new ExpBool();
				int k = exp.setExpresio(textField.getText());
				if(k == -1){
					
				}
				else{
					ConsultaBooleana cb = null;
					try {
						cb = new ConsultaBooleana(c.cd().conjunto(), textField.getText());
					} catch (ParseException | IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					ArrayList<Documento> res = cb.getResult();
					DefaultListModel dlm = new DefaultListModel();
					//errorSel.setVisible(false);
					for(int i = 0; i < res.size(); ++i){
						dlm.addElement(res.get(i));
					}
					list.setModel(dlm);
				}
				
			}
		});
		Buscar.setBounds(309, 76, 117, 25);
		contentPane.add(Buscar);
		
		JButton btnVer = new JButton("Ver");
		btnVer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Documento d = (Documento) list.getSelectedValue();
				c.setAutor(d.getAutor());
				c.setTitulo(d.getTitulo());
				c.llamarp3();
				dispose();
			}
		});
		btnVer.setBounds(309, 144, 117, 25);
		contentPane.add(btnVer);

	}
}

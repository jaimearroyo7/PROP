package interficie;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import dominio.Texto;

public class Ventana5 extends JFrame implements Serializable{

	private JPanel contentPane;
	private JTextField textField;
	private static final long serialVersionUID = -7821004374586134671L;

	
	public Ventana5(final CtrlPresentacio c) {
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		contentPane = new JPanel();
		contentPane.setFont(new Font("Dialog", Font.PLAIN, 14));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		this.setLocationRelativeTo(null);
		
		this.setVisible(true);
		textField = new JTextField();
		textField.setBounds(138, 27, 138, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		textField.setText(c.getAutor());
		
		JLabel lblAutor = new JLabel("Autor:");
		lblAutor.setFont(new Font("Dialog", Font.BOLD, 14));
		lblAutor.setBounds(81, 23, 73, 26);
		contentPane.add(lblAutor);
		
		final JLabel selecciona = new JLabel("Selecciona!");
		selecciona.setFont(new Font("Dialog", Font.BOLD, 14));
		selecciona.setBounds(81, 347, 96, 15);
		contentPane.add(selecciona);
		selecciona.setVisible(false);
		final JLabel SinRes = new JLabel("Sin resultados");
		SinRes.setBounds(141, 44, 135, 15);
		contentPane.add(SinRes);
		SinRes.setVisible(false);
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(48, 65, 144, 270);
		contentPane.add(scrollPane);
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(221, 65, 205, 268);
		contentPane.add(scrollPane_1);
		
		final JTextArea contenido = new JTextArea();
		scrollPane_1.setViewportView(contenido);
		
		final JList<String> list = new JList<String>();
		scrollPane.setViewportView(list);
		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String selected = (String) list.getSelectedValue();
				Texto t = c.cd().conjunto().consultarTextoDadoTituloAutor(selected, textField.getText());
				contenido.setText(t.getTexto());
			}
		});
		
		JButton btnNewButton = new JButton("Buscar");
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selecciona.setVisible(false);
				
				ArrayList<String> al = c.cd().conjunto().consultarTitulosAutor(textField.getText());
				if(al.size() == 0){
					SinRes.setVisible(true);
					contenido.setText("");
				}
				
				else SinRes.setVisible(false);
				DefaultListModel<String> dlm = new DefaultListModel<String>();
				for(int i = 0; i < al.size(); ++i){
					dlm.addElement(al.get(i));
				}
				list.setModel(dlm);
				//list = new JList(titulos);
				
			}
		});
		btnNewButton.setBounds(288, 27, 161, 19);
		contentPane.add(btnNewButton);
		
		
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Dialog", Font.BOLD, 14));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}
		});
		btnExit.setBounds(12, 403, 117, 25);
		contentPane.add(btnExit);
		
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Dialog", Font.BOLD, 14));
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp4();
				dispose();
				}
		});
		btnVolver.setBounds(427, 403, 117, 25);
		contentPane.add(btnVolver);
		
		JButton button = new JButton("<");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				c.llamarp1();
				dispose();
			}
		});
		button.setBounds(555, 403, 21, 25);
		contentPane.add(button);
		
		JButton btnVer = new JButton("Modificar doc");
		btnVer.setFont(new Font("Dialog", Font.BOLD, 14));
		btnVer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(list.getSelectedIndex() == -1){
					selecciona.setVisible(true);
				}
				else{
					c.setAutor(textField.getText());
					c.setTitulo((String)list.getSelectedValue());
					c.setVolver(5);
					c.llamarp3();
					dispose();
				}
				
				
			}
		});
		btnVer.setBounds(231, 345, 210, 19);
		contentPane.add(btnVer);
		
		JLabel lblListaDeTtulos = new JLabel("Lista de títulos de un autor:");
		lblListaDeTtulos.setFont(new Font("Dialog", Font.BOLD, 20));
		lblListaDeTtulos.setBounds(90, 0, 336, 15);
		contentPane.add(lblListaDeTtulos);
	
	}
}
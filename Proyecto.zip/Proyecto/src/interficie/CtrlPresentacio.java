package interficie;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.URISyntaxException;
import java.text.ParseException;

import dominio.CtrlDominio;

public class CtrlPresentacio implements Serializable{
	
	private CtrlDominio cd = null;
	private static final long serialVersionUID = -7821004374586134671L;
	
	private String autor = null;
	private String titulo = null;
	int volver = 1;
	
	private Principal p1;
	private Ventana2 p2;
	@SuppressWarnings("unused")
	private Ventana2_1 p2_1;
	@SuppressWarnings("unused")
	private Ventana2_2 p2_2;
	@SuppressWarnings("unused")
	private Ventana3 p3;
	@SuppressWarnings("unused")
	private Ventana4 p4;
	@SuppressWarnings("unused")
	private Ventana5 p5;
	@SuppressWarnings("unused")
	private Ventana6 p6;
	@SuppressWarnings("unused")
	private Ventana7 p7;
	@SuppressWarnings("unused")
	private Ventana8 p8;
	@SuppressWarnings("unused")
	private Ventana9 p9;
	@SuppressWarnings("unused")
	private Ventana10 p10;
	@SuppressWarnings("unused")
	private Ventana13 p13;
	@SuppressWarnings("unused")
	private Ventana14 p14;
	@SuppressWarnings("unused")
	private Ventana15 p15;
	@SuppressWarnings("unused")
	private Ventana16 p16;
	@SuppressWarnings("unused")
	private Ventana17 p17;
	
	
	public CtrlPresentacio(){
		
	}
	
	public void empezar() throws URISyntaxException{
		try {
			cd = new CtrlDominio();
		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		p1 = new Principal(this);
	}
	
	public CtrlDominio cd(){ return cd;}
	
	public void llamarp1(){ p1 = new Principal(this); }
	public boolean getvolver() { return p1.getVolver(); }
	public void llamarp2(){ setP2(new Ventana2(this)); }
	public void llamarp2_1(){ p2_1 = new Ventana2_1(this); }
	public void llamarp2_2(){ p2_2 = new Ventana2_2(this); }
	public void llamarp3(){ p3 = new Ventana3(this); }
	public void llamarp4(){ p4 = new Ventana4(this); }
	public void llamarp5(){ p5 = new Ventana5(this); }
	public void llamarp6(){ p6 = new Ventana6(this); }
	public void llamarp7(){ p7 = new Ventana7(this); }
	public void llamarp8(){ p8 = new Ventana8(this); }
	public void llamarp9(){ p9 = new Ventana9(this); }
	public void llamarp10(){ p10 = new Ventana10(this); }
	public void llamarp13(){ p13 = new Ventana13(this); }
	public void llamarp14(){ p14 = new Ventana14(this); }
	public void llamarp15(){ p15 = new Ventana15(this);}
	public void llamarp16(){ p16 = new Ventana16(this);}
	public void llamarp17(){ p17 = new Ventana17(this);}
	
	
	public void setAutor(String a){
		autor = a;
	}
	
	public String getAutor(){return autor;}
	
	
	public void setTitulo(String a){
		titulo = a;
	}
	
	public String getTitulo(){return titulo;}
	
	@SuppressWarnings("resource")
	public void acabar() throws IOException{
		ObjectOutputStream oos = null;
		oos = new ObjectOutputStream(new FileOutputStream("src/persistencia/datos/data.bin"));
		oos.writeObject(cd.conjunto());
	}
	
	public int getVolver(){return volver;}
	public void setVolver(int k){volver = k;}
	
	public void volver(int k){
		switch(k){
		case 1: this.llamarp1();
				break;
		case 2: this.llamarp2(); 
				break;
		case 3: this.llamarp3(); 
				break;
		case 4: this.llamarp4(); 
				break;
		case 5: this.llamarp5(); 
				break;
		case 6: this.llamarp6(); 
				break;
		case 7: this.llamarp7();
				break;
		case 8: this.llamarp8(); 
				break;
		case 9: this.llamarp9(); 
				break;
		case 10: this.llamarp10(); 
				break;
		case 13: this.llamarp13(); 
				break;
		case 14: this.llamarp14(); 
				break;
		case 15: this.llamarp15(); 
				break;
		case 16: this.llamarp16(); 
				break;
		case 17: this.llamarp17();
				break;
		default: this.llamarp1();
				break;
		}
	}

	public Ventana2 getP2() {
		return p2;
	}

	public void setP2(Ventana2 p2) {
		this.p2 = p2;
	}
	
}

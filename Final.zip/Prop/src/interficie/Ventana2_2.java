package interficie;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Ventana2_2 extends JFrame implements Serializable{

	private JPanel contentPane;
	private boolean clicked;
	private static final long serialVersionUID = -7821004374586134671L;

	public Ventana2_2(final CtrlPresentacio c) {
		clicked = false;
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		
		
		
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		this.setLocationRelativeTo(null);
		
		this.setVisible(true);
		
		final JLabel textField = new JLabel("");
		textField.setBounds(128, 121, 276, 15);
		contentPane.add(textField);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(12, 403, 117, 25);
		btnExit.addActionListener(new ActionListener() {
			@SuppressWarnings("unused")
			public void actionPerformed1(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnExit);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setBounds(418, 403, 117, 25);
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp2();
				dispose();
			}
		});
		contentPane.add(btnVolver);
		
		final JLabel elige = new JLabel("Elige Carpeta: ");
		elige.setFont(new Font("Dialog", Font.BOLD, 16));
		elige.setBounds(105, 160, 132, 15);
		contentPane.add(elige);
		
		JButton button = new JButton("<");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				c.llamarp1();
				dispose();
			}
		});
		button.setBounds(551, 403, 25, 25);
		contentPane.add(button);
		
		
		JButton Examinar = new JButton("Examinar");
		Examinar.setFont(new Font("Dialog", Font.BOLD, 14));
		Examinar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int seleccion = fc.showOpenDialog(contentPane);
				
				if(seleccion == JFileChooser.APPROVE_OPTION){
					
					File fichero = fc.getSelectedFile();
					textField.setText(fichero.getAbsolutePath());
					clicked = true;
				}
			}
		});
		Examinar.setBounds(287, 148, 117, 39);
		contentPane.add(Examinar);
		
		JButton Importar = new JButton("Importar");
		Importar.setFont(new Font("Dialog", Font.BOLD, 14));
		Importar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String path = textField.getText();
				if(clicked){
					try {
						c.cd().addCarpeta(path);
					} catch (IOException | ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					c.llamarp2();
					dispose();
				}
				else{
					textField.setText("Selecciona una carpeta!");
				}
			}
		});
		Importar.setBounds(202, 228, 117, 42);
		contentPane.add(Importar);
		
		JLabel lblNewLabel = new JLabel("Importar desde Carpeta");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel.setBounds(128, 12, 305, 31);
		contentPane.add(lblNewLabel);
		

		
		
	}
}
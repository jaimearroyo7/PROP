package interficie;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import dominio.Documento;

public class Ventana9 extends JFrame implements Serializable{
	
	private JPanel jpanel;
	private JList<String> list;
	private ArrayList<Documento> res = new ArrayList<Documento>();
	private static final long serialVersionUID = -7821004374586134671L;

	public Ventana9(final CtrlPresentacio c) {
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		jpanel = new JPanel();
		jpanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(jpanel);
		jpanel.setLayout(null);
		this.setLocationRelativeTo(null);
		
		this.setVisible(true);
		
		JLabel lblPrefijo = new JLabel("Fecha:");
		lblPrefijo.setFont(new Font("Dialog", Font.BOLD, 14));
		lblPrefijo.setBounds(35, 29, 174, 15);
		jpanel.add(lblPrefijo);
		
		final JLabel SinRes = new JLabel("Sin resultados");
		SinRes.setBounds(190, 56, 106, 15);
		jpanel.add(SinRes);
		SinRes.setVisible(false);
		
		final JLabel errorSel = new JLabel("Selecciona un doc. !");
		errorSel.setBounds(65, 359, 153, 19);
		jpanel.add(errorSel);
		errorSel.setVisible(false);
		
		
		UtilDateModel udm = new UtilDateModel();
		udm.setSelected(true);
		Properties p = new Properties();
		p.put("text.today", "Today");
		p.put("text.month", "Month");
		p.put("text.year", "Year");
		JDatePanelImpl datePanel = new JDatePanelImpl(udm, p);
		final JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());
		datePicker.setBounds(104, 23, 222, 26);
		jpanel.add(datePicker);
		
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setFont(new Font("Dialog", Font.BOLD, 14));
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Date selected = (Date) datePicker.getModel().getValue();
				Calendar cal = Calendar.getInstance();
				cal.setTime(selected);
				int da = cal.get(Calendar.DAY_OF_MONTH);
				int m = cal.get(Calendar.MONTH)+1;
				int y = cal.get(Calendar.YEAR);
				
				String d = da + "/" + m + "/" + y;
				//System.out.println(d);
				
				
				try {
					res = c.cd().conjunto().consultarAutoryTituloDadoFecha(d);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if(res.size() == 0){
					SinRes.setVisible(true);
				}
				else SinRes.setVisible(false);
				DefaultListModel<String> dlm = new DefaultListModel<String>();
				errorSel.setVisible(false);
				for(int i = 0; i < res.size(); ++i){
					String s = res.get(i).getAutor() + ": " + res.get(i).getTitulo();
					dlm.addElement(s);
				}
				list.setModel(dlm);
			}
		});
		btnBuscar.setBounds(338, 27, 100, 19);
		jpanel.add(btnBuscar);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Dialog", Font.BOLD, 14));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}
		});
		btnExit.setBounds(12, 403, 117, 25);
		jpanel.add(btnExit);
		
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Dialog", Font.BOLD, 14));
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp4();
				dispose();
				}
		});
		btnVolver.setBounds(413, 403, 117, 25);
		jpanel.add(btnVolver);
		
		JButton button = new JButton("<");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				c.llamarp1();
				dispose();
			}
		});
		button.setBounds(552, 403, 24, 25);
		jpanel.add(button);
		
		JButton titulos = new JButton("Ver");
		titulos.setFont(new Font("Dialog", Font.BOLD, 14));
		titulos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(list.getSelectedIndex() == -1){
					errorSel.setVisible(true);
				}
				else{
				int i = list.getSelectedIndex();
				c.setAutor(res.get(i).getAutor());
				c.setTitulo(res.get(i).getTitulo());
				c.setVolver(9);
				c.llamarp3();
				dispose();}
			}
		});
		titulos.setBounds(278, 356, 137, 25);
		jpanel.add(titulos);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(65, 83, 350, 261);
		jpanel.add(scrollPane);
		
		list = new JList<String>();
		list.setBounds(65, 83, 350, 109);
		scrollPane.setViewportView(list);
		
		JLabel lblConsultaPorFecha = new JLabel("Consulta por fecha");
		lblConsultaPorFecha.setFont(new Font("Dialog", Font.BOLD, 14));
		lblConsultaPorFecha.setBounds(148, 0, 172, 15);
		jpanel.add(lblConsultaPorFecha);
		
		
		
		
	}
}

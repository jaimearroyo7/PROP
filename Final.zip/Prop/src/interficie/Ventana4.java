package interficie;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Ventana4 extends JFrame implements Serializable{

	private JPanel contentPane;
	private static final long serialVersionUID = -7821004374586134671L;

	public Ventana4(final CtrlPresentacio c) {
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		this.setLocationRelativeTo(null);
		
		this.setVisible(true);
		JButton btnNewButton = new JButton("Lista de títulos de un autor");
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setAutor(null);
				c.setTitulo(null);
				c.setVolver(4);
				c.llamarp5();
				dispose();
			}
		});
		btnNewButton.setBounds(125, 130, 334, 25);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Lísta de autores dado un prefijo");
		btnNewButton_1.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setAutor(null);
				c.setTitulo(null);
				c.setVolver(4);
				c.llamarp6();
				dispose();
			}
		});
		btnNewButton_1.setBounds(125, 154, 334, 25);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Contenido de un Documento");
		btnNewButton_2.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setAutor(null);
				c.setTitulo(null);
				c.setVolver(4);
				c.llamarp3();
				dispose();
			}
		});
		btnNewButton_2.setBounds(125, 179, 334, 25);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Documentos Parecidos");
		btnNewButton_3.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setAutor(null);
				c.setTitulo(null);
				c.setVolver(4);
				c.llamarp13();
				dispose();
			}
		});
		btnNewButton_3.setBounds(125, 204, 334, 25);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Expresión booleana");
		btnNewButton_4.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setVolver(4);
				c.llamarp10();
				dispose();
			}
		});
		btnNewButton_4.setBounds(125, 229, 334, 25);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Historico de Documentos");
		btnNewButton_5.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setVolver(4);
				c.llamarp16();
				dispose();
			}
		});
		btnNewButton_5.setBounds(125, 254, 334, 25);
		contentPane.add(btnNewButton_5);
		
		JLabel lblConsultas = new JLabel("Consultas");
		lblConsultas.setFont(new Font("Dialog", Font.BOLD, 20));
		lblConsultas.setBounds(229, 51, 163, 40);
		contentPane.add(lblConsultas);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Dialog", Font.BOLD, 14));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}
		});
		btnExit.setBounds(12, 403, 117, 25);
		contentPane.add(btnExit);
		
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Dialog", Font.BOLD, 14));
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp1();
				dispose();
				}
		});
		btnVolver.setBounds(459, 403, 117, 25);
		contentPane.add(btnVolver);
		
		JButton btnNewButton_6 = new JButton("Consultar por categoría");
		btnNewButton_6.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setVolver(4);
				c.llamarp8();
				dispose();
			}
		});
		btnNewButton_6.setBounds(125, 279, 334, 25);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Consultar por fecha");
		btnNewButton_7.setFont(new Font("Dialog", Font.BOLD, 14));
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setVolver(4);
				c.llamarp9();
				dispose();
			}
		});
		btnNewButton_7.setBounds(125, 304, 334, 25);
		contentPane.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("Ver todos los Documentos");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.setVolver(4);
				c.llamarp11();
				dispose();
			}
		});
		btnNewButton_8.setBounds(125, 329, 334, 25);
		contentPane.add(btnNewButton_8);
	}
}
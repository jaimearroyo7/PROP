package interficie;

import java.awt.BorderLayout;
import java.io.Serializable;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class p0 extends JFrame implements Serializable{

	private JPanel contentPane;
	private static final long serialVersionUID = -7821004374586134671L;

	public p0(CtrlPresentacio c) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		c.llamarp1();
		dispose();
	}

}

package interficie;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Ventana6 extends JFrame implements Serializable{
	
	private JPanel jpanel;
	private JTextField textField;
	private JScrollPane scrollPane;
	private JList<String> list;
	private static final long serialVersionUID = -7821004374586134671L;

	public Ventana6(final CtrlPresentacio c) {
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		jpanel = new JPanel();
		jpanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(jpanel);
		jpanel.setLayout(null);

		this.setLocationRelativeTo(null);
		
		this.setVisible(true);
		JLabel lblPrefijo = new JLabel("Prefijo:");
		lblPrefijo.setFont(new Font("Dialog", Font.BOLD, 14));
		lblPrefijo.setBounds(67, 23, 70, 15);
		jpanel.add(lblPrefijo);
		
		final JLabel SinRes = new JLabel("Sin resultados");
		SinRes.setBounds(411, 69, 106, 15);
		jpanel.add(SinRes);
		SinRes.setVisible(false);
		
		textField = new JTextField();
		textField.setBounds(138, 21, 114, 19);
		jpanel.add(textField);
		textField.setColumns(10);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(65, 67, 304, 293);
		jpanel.add(scrollPane);
		
		final JLabel errorSel = new JLabel("Selecciona un autor");
		errorSel.setBounds(387, 338, 153, 19);
		jpanel.add(errorSel);
		errorSel.setVisible(false);
		
		list = new JList<String>();
		scrollPane.setViewportView(list);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setFont(new Font("Dialog", Font.BOLD, 14));
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ArrayList<String> al = c.cd().conjunto().consultarAutoresPrefijo(textField.getText());
				if(al.size() == 0) SinRes.setVisible(true);
				else SinRes.setVisible(false);
				DefaultListModel<String> dlm = new DefaultListModel<String>();
				errorSel.setVisible(false);
				for(int i = 0; i < al.size(); ++i){
					dlm.addElement(al.get(i));
				}
				list.setModel(dlm);
			}
		});
		btnBuscar.setBounds(285, 21, 100, 19);
		jpanel.add(btnBuscar);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Dialog", Font.BOLD, 14));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}
		});
		btnExit.setBounds(12, 403, 117, 25);
		jpanel.add(btnExit);
		
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Dialog", Font.BOLD, 14));
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp4();
				dispose();
				}
		});
		btnVolver.setBounds(423, 403, 117, 25);
		jpanel.add(btnVolver);
		
		JButton button = new JButton("<");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				c.llamarp1();
				dispose();
			}
		});
		button.setBounds(552, 403, 24, 25);
		jpanel.add(button);
		
		JButton titulos = new JButton("Mostrar títulos");
		titulos.setFont(new Font("Dialog", Font.BOLD, 14));
		titulos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(list.isSelectionEmpty()){
					errorSel.setVisible(true);
				}
				else{
				c.setAutor((String)list.getSelectedValue());
				c.setVolver(6);
				c.llamarp5();
				dispose();}
			}
		});
		titulos.setBounds(387, 197, 151, 25);
		jpanel.add(titulos);
		
	}
}
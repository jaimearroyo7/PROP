package interficie;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.Font;

public class Ventana2 extends JFrame implements Serializable{

	private JPanel contentPane;
	private static final long serialVersionUID = -7821004374586134671L;

	
	public Ventana2(final CtrlPresentacio c) {
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		WindowListener exitListener = new WindowAdapter() {

		    @Override
		    public void windowClosing(WindowEvent e) {
		        int confirm = JOptionPane.showOptionDialog(
		             null, "Desea cerrar la aplicacion?", 
		             "Exit Confirmation", JOptionPane.YES_NO_OPTION, 
		             JOptionPane.QUESTION_MESSAGE, null, null, null);
		        if (confirm == 0) {
		        	try {
						c.acabar();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(1);
		        }
		    }
		};
		addWindowListener(exitListener);
		setBounds(100, 100, 588, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		JButton nuevo = new JButton("Añadir Documento Nuevo");
		nuevo.setFont(new Font("Dialog", Font.BOLD, 14));
		nuevo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp2_1();
				dispose();
			}
		});
		nuevo.setBounds(103, 131, 381, 35);
		contentPane.add(nuevo);
		
		JButton importar = new JButton("Importar desde Carpeta");
		importar.setFont(new Font("Dialog", Font.BOLD, 14));
		importar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp2_2();
				dispose();
			}
		});
		importar.setBounds(103, 251, 381, 35);
		contentPane.add(importar);
		
		
		
		
		
		
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					c.acabar();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(1);
			}
		});
		btnExit.setBounds(12, 403, 117, 25);
		contentPane.add(btnExit);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.llamarp1();
				dispose();
				}
		});
		btnVolver.setBounds(459, 403, 117, 25);
		contentPane.add(btnVolver);
		
		JLabel lblAadir = new JLabel("Añadir");
		lblAadir.setFont(new Font("Dialog", Font.BOLD, 21));
		lblAadir.setBounds(245, 12, 117, 35);
		contentPane.add(lblAadir);
		
	}
	
}
